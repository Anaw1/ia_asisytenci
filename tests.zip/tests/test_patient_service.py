"""Pruebas del servicio de pacientes: registro, historial y conservación de datos ausentes."""
import sqlite3

from database import get_connection, init_db
from patient_service import (
    get_patient_history,
    register_measurement,
    register_patient,
    update_status,
)
from validation import validate_measurement


def test_register_and_query_patient(db_path):
    """Un paciente ficticio registrado se puede consultar con estado inicial 'en_espera'."""
    result = register_patient(patient_code='PAC-SVC-01', db_path=db_path)
    assert result['success'] is True
    history = get_patient_history(result['patient_id'], db_path=db_path)
    assert history['patient'].patient_code == 'PAC-SVC-01'
    assert history['patient'].administrative_status == 'en_espera'


def test_duplicate_patient_code_is_rejected(db_path):
    """No se permiten dos pacientes con el mismo código."""
    assert register_patient(patient_code='PAC-DUP-01', db_path=db_path)['success']
    second = register_patient(patient_code='PAC-DUP-01', db_path=db_path)
    assert second['success'] is False
    assert second['errors']


def test_multiple_measurements_are_kept_in_history(registered_patient, sample_measurement_complete, db_path):
    """Varias mediciones del mismo paciente se conservan en el historial."""
    patient_id, _ = registered_patient
    for minutes in range(3):
        data = dict(sample_measurement_complete, recorded_at=f'2026-01-01T10:0{minutes}:00')
        assert register_measurement(patient_id, data, db_path=db_path)['success']
    history = get_patient_history(patient_id, db_path=db_path)
    assert len(history['measurements']) == 3


def test_missing_fields_are_stored_as_none_not_replaced_by_normal_values(
    registered_patient, sample_measurement_incomplete, db_path
):
    """Los datos ausentes se guardan como None; no se sustituyen por 'aire' ni por 'alerta'."""
    patient_id, _ = registered_patient
    data = dict(sample_measurement_incomplete)
    data['consciousness_status'] = None
    result = register_measurement(patient_id, data, db_path=db_path)
    assert result['success'] is True

    stored = get_patient_history(patient_id, db_path=db_path)['measurements'][0]
    assert stored.supplemental_oxygen is None
    assert stored.consciousness_status is None
    assert stored.oxygen_saturation is None
    assert stored.temperature is None


def test_invalid_measurement_is_rejected_and_not_saved(registered_patient, db_path):
    """Un valor fuera de rango se rechaza y no se guarda ninguna medición."""
    patient_id, _ = registered_patient
    result = register_measurement(patient_id, {'respiratory_rate': 500}, db_path=db_path)
    assert result['success'] is False
    assert get_patient_history(patient_id, db_path=db_path)['measurements'] == []


def test_measurement_for_unknown_patient_is_rejected(db_path, sample_measurement_complete):
    """No se registran mediciones de un paciente inexistente."""
    result = register_measurement(9999, sample_measurement_complete, db_path=db_path)
    assert result['success'] is False


def test_invalid_status_is_rejected(registered_patient, db_path):
    """Un estado administrativo desconocido no se aplica."""
    patient_id, _ = registered_patient
    assert update_status(patient_id, 'inventado', db_path=db_path)['success'] is False
    assert update_status(patient_id, 'en_atencion', db_path=db_path)['success'] is True


def test_spo2_scale_defaults_to_1_and_is_persisted(registered_patient, sample_measurement_complete, db_path):
    """Sin indicación explícita se guarda la Escala 1; la Escala 2 se conserva si se indica."""
    patient_id, _ = registered_patient
    register_measurement(patient_id, sample_measurement_complete, db_path=db_path)
    register_measurement(patient_id, dict(sample_measurement_complete, spo2_scale=2), db_path=db_path)

    measurements = get_patient_history(patient_id, db_path=db_path)['measurements']
    assert sorted(m.spo2_scale for m in measurements) == [1, 2]


def test_invalid_spo2_scale_is_rejected():
    """Una escala distinta de 1 o 2 es un error de validación, no se corrige en silencio."""
    result = validate_measurement({'spo2_scale': 3})
    assert result.is_valid is False
    assert result.errors


def test_init_db_migrates_old_measurements_table_without_losing_data(tmp_path):
    """Una base creada antes de spo2_scale se migra conservando sus filas."""
    path = str(tmp_path / 'old.db')
    raw = sqlite3.connect(path)
    raw.executescript(
        """
        CREATE TABLE patients (
            id INTEGER PRIMARY KEY AUTOINCREMENT, patient_code TEXT NOT NULL UNIQUE,
            created_at TEXT NOT NULL, arrival_at TEXT NOT NULL,
            administrative_status TEXT NOT NULL DEFAULT 'en_espera',
            is_simulated INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE measurements (
            id INTEGER PRIMARY KEY AUTOINCREMENT, patient_id INTEGER NOT NULL,
            recorded_at TEXT NOT NULL, respiratory_rate INTEGER, oxygen_saturation INTEGER,
            supplemental_oxygen INTEGER, systolic_blood_pressure INTEGER, heart_rate INTEGER,
            temperature REAL, consciousness_status TEXT,
            measurement_source TEXT NOT NULL DEFAULT 'manual',
            FOREIGN KEY (patient_id) REFERENCES patients(id)
        );
        INSERT INTO patients (patient_code, created_at, arrival_at) VALUES ('PAC-OLD-1', 'x', 'x');
        INSERT INTO measurements (patient_id, recorded_at, respiratory_rate) VALUES (1, 'x', 16);
        """
    )
    raw.commit()
    raw.close()

    init_db(path)

    conn = get_connection(path)
    try:
        row = conn.execute('SELECT respiratory_rate, spo2_scale FROM measurements').fetchone()
        assert row['respiratory_rate'] == 16
        assert row['spo2_scale'] == 1
    finally:
        conn.close()
