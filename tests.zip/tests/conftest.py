import pytest
import os
import sys

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database import init_db, get_connection
from models import Patient, Measurement, Evaluation, Alert
from datetime import datetime
from config import DATE_FORMAT

@pytest.fixture
def db_path(tmp_path):
    """Create a temporary database for testing."""
    path = str(tmp_path / 'test_triage.db')
    init_db(path)
    return path

@pytest.fixture
def db_conn(db_path):
    """Get a connection to the test database."""
    conn = get_connection(db_path)
    yield conn
    conn.close()

@pytest.fixture
def sample_patient():
    """Create a sample patient for testing."""
    now = datetime.now().strftime(DATE_FORMAT)
    return Patient(
        patient_code='PAC-TEST0001',
        created_at=now,
        arrival_at=now,
        administrative_status='en_espera',
        is_simulated=False
    )

@pytest.fixture
def sample_measurement_complete():
    """A complete measurement with all fields for NEWS2."""
    return {
        'respiratory_rate': 18,
        'oxygen_saturation': 96,
        'supplemental_oxygen': False,
        'systolic_blood_pressure': 120,
        'heart_rate': 75,
        'temperature': 36.8,
        'consciousness_status': 'A'
    }

@pytest.fixture
def sample_measurement_incomplete():
    """An incomplete measurement missing some fields."""
    return {
        'respiratory_rate': 18,
        'oxygen_saturation': None,
        'supplemental_oxygen': None,
        'systolic_blood_pressure': 120,
        'heart_rate': 75,
        'temperature': None,
        'consciousness_status': 'A'
    }

@pytest.fixture
def sample_measurement_critical():
    """A measurement with critical values."""
    return {
        'respiratory_rate': 28,
        'oxygen_saturation': 88,
        'supplemental_oxygen': True,
        'systolic_blood_pressure': 85,
        'heart_rate': 140,
        'temperature': 39.5,
        'consciousness_status': 'V'
    }

@pytest.fixture 
def registered_patient(db_path):
    """Register a patient and return (patient_id, patient_code)."""
    from patient_service import register_patient
    result = register_patient(patient_code='PAC-FIXTURE1', db_path=db_path)
    assert result['success']
    return result['patient_id'], result['patient_code']


@pytest.fixture
def evaluate_measurement(db_path):
    """Devuelve una función que registra una medición y la evalúa igual que la aplicación.

    Uso: ``measurement, outcome = evaluate_measurement(patient_id, datos, recorded_at=None)``.
    La medición se persiste primero (con id) y luego la evalúa el motor de alertas.
    """
    from alert_engine import AlertEngine
    from patient_service import register_measurement

    engine = AlertEngine(db_path=db_path)

    def _run(patient_id, data, recorded_at=None):
        payload = dict(data)
        if recorded_at is not None:
            payload['recorded_at'] = recorded_at
        registration = register_measurement(patient_id, payload, db_path=db_path)
        assert registration['success'], registration['errors']
        outcome = engine.evaluate_new_measurement(patient_id, registration['measurement'])
        return registration['measurement'], outcome

    _run.engine = engine
    return _run
