"""Tests for clinical simulation module."""
import pytest
from models import SimulationConfig, Patient
from simulation import run_simulation, clear_simulation_data
from database import get_connection, get_all_patients, get_measurements_for_patient, get_simulation_events
from patient_service import register_patient


def test_simulation_creates_specified_number_of_patients(db_path):
    """Verify that the simulation creates exactly the requested number of patients."""
    config = SimulationConfig(
        num_patients=5,
        duration_hours=2,
        measurement_interval_minutes=30,
        random_seed=42,
        simulation_id='SIM-TEST-01'
    )
    result = run_simulation(config=config, db_path=db_path)
    assert result.get('success') is True

    conn = get_connection(db_path)
    try:
        patients = get_all_patients(conn, include_simulated=True)
        assert len(patients) == 5
    finally:
        conn.close()


def test_simulation_generates_measurements(db_path):
    """Verify that measurements are generated for simulated patients across the timeline."""
    config = SimulationConfig(
        num_patients=3,
        duration_hours=2,
        measurement_interval_minutes=30,
        random_seed=123,
        simulation_id='SIM-TEST-02'
    )
    result = run_simulation(config=config, db_path=db_path)
    assert result.get('success') is True

    conn = get_connection(db_path)
    try:
        patients = get_all_patients(conn, include_simulated=True)
        assert len(patients) == 3
        total_measurements = 0
        for p in patients:
            m_list = get_measurements_for_patient(conn, p.id)
            assert len(m_list) > 0, f"Patient {p.patient_code} has no measurements"
            total_measurements += len(m_list)
        assert total_measurements >= 3
    finally:
        conn.close()


def test_simulation_generates_events(db_path):
    """Verify that simulation events are logged and retrievable."""
    sim_id = 'SIM-TEST-EVENTS'
    config = SimulationConfig(
        num_patients=3,
        duration_hours=2,
        measurement_interval_minutes=30,
        random_seed=42,
        simulation_id=sim_id
    )
    result = run_simulation(config=config, db_path=db_path)
    assert result.get('success') is True

    conn = get_connection(db_path)
    try:
        events = get_simulation_events(conn, simulation_id=sim_id)
        assert len(events) > 0
    finally:
        conn.close()


def _simulation_fingerprint(db_path):
    """Valores clínicos y puntuaciones por paciente (sin ids, códigos ni marcas de tiempo)."""
    from database import get_evaluations_for_patient

    conn = get_connection(db_path)
    try:
        fingerprint = []
        for patient in get_all_patients(conn, include_simulated=True):
            measurements = [
                (m.respiratory_rate, m.oxygen_saturation, m.supplemental_oxygen,
                 m.systolic_blood_pressure, m.heart_rate, m.temperature, m.consciousness_status)
                for m in get_measurements_for_patient(conn, patient.id)
            ]
            scores = [e.score for e in get_evaluations_for_patient(conn, patient.id)]
            fingerprint.append((measurements, scores))
        return fingerprint
    finally:
        conn.close()


def _run_in_new_db(tmp_path, name, seed):
    from database import init_db

    path = str(tmp_path / f'{name}.db')
    init_db(path)
    config = SimulationConfig(
        num_patients=5, duration_hours=2, measurement_interval_minutes=30,
        random_seed=seed, simulation_id=f'SIM-{name}',
    )
    assert run_simulation(config, db_path=path)['success'] is True
    return _simulation_fingerprint(path)


def test_simulation_is_reproducible_with_same_seed(tmp_path):
    """La misma semilla produce las mismas mediciones y puntuaciones; otra semilla, distintas."""
    first = _run_in_new_db(tmp_path, 'rep1', seed=999)
    second = _run_in_new_db(tmp_path, 'rep2', seed=999)
    different = _run_in_new_db(tmp_path, 'rep3', seed=1000)

    assert len(first) == 5
    assert first == second
    assert first != different


def test_simulation_persists_news2_evaluations(db_path):
    """Cada medición simulada genera su evaluación NEWS2 (la cola depende de ella)."""
    from database import get_evaluations_for_patient

    config = SimulationConfig(
        num_patients=5, duration_hours=2, measurement_interval_minutes=30,
        random_seed=42, simulation_id='SIM-EVALS',
    )
    assert run_simulation(config, db_path=db_path)['success'] is True

    conn = get_connection(db_path)
    try:
        for patient in get_all_patients(conn, include_simulated=True):
            measurements = get_measurements_for_patient(conn, patient.id)
            evaluations = get_evaluations_for_patient(conn, patient.id)
            assert len(evaluations) == len(measurements) > 0
    finally:
        conn.close()



def test_clear_simulation_data(db_path):
    """Verify clear_simulation_data purges simulated records from the database."""
    config = SimulationConfig(
        num_patients=4,
        duration_hours=2,
        measurement_interval_minutes=30,
        random_seed=42,
        simulation_id='SIM-CLEAR'
    )
    run_simulation(config=config, db_path=db_path)

    conn = get_connection(db_path)
    try:
        assert len(get_all_patients(conn, include_simulated=True)) == 4
    finally:
        conn.close()

    clear_result = clear_simulation_data(simulation_id='SIM-CLEAR', db_path=db_path)
    assert clear_result.get('success') is True or isinstance(clear_result, dict)

    conn = get_connection(db_path)
    try:
        remaining = get_all_patients(conn, include_simulated=True)
        assert len(remaining) == 0
    finally:
        conn.close()


def test_invalid_config_is_rejected(db_path):
    """Verify that invalid configuration values fail validation and reject simulation execution."""
    invalid_config = SimulationConfig(
        num_patients=0,
        duration_hours=-1,
        measurement_interval_minutes=0,
        random_seed=42,
        simulation_id='SIM-INVALID'
    )
    result = run_simulation(config=invalid_config, db_path=db_path)
    assert result.get('success') is False or 'error' in result


def test_simulated_patients_marked_is_simulated(db_path):
    """Verify that all patients generated by simulation have is_simulated set to True."""
    config = SimulationConfig(
        num_patients=3,
        duration_hours=2,
        measurement_interval_minutes=30,
        random_seed=42,
        simulation_id='SIM-FLAGS'
    )
    run_simulation(config=config, db_path=db_path)

    conn = get_connection(db_path)
    try:
        patients = get_all_patients(conn, include_simulated=True)
        assert len(patients) == 3
        for p in patients:
            assert bool(p.is_simulated) is True
    finally:
        conn.close()


def test_simulation_events_have_correct_types(db_path):
    """Verify that generated simulation events contain standard event type designations."""
    sim_id = 'SIM-EVENT-TYPES'
    config = SimulationConfig(
        num_patients=3,
        duration_hours=2,
        measurement_interval_minutes=30,
        random_seed=42,
        simulation_id=sim_id
    )
    run_simulation(config=config, db_path=db_path)

    conn = get_connection(db_path)
    try:
        events = get_simulation_events(conn, simulation_id=sim_id)
        assert len(events) > 0
        valid_types = {'ingreso', 'medicion', 'evaluacion', 'alerta', 'cambio_cola'}
        found_types = {ev.event_type for ev in events}
        assert found_types <= valid_types, f"Tipos inesperados: {found_types - valid_types}"
        assert {'ingreso', 'medicion', 'evaluacion', 'cambio_cola'} <= found_types
    finally:
        conn.close()


def test_non_simulated_patients_preserved_on_clear(db_path):
    """Verify that clearing simulation data does not delete real (non-simulated) patients."""
    # Register real patient
    real_res = register_patient(patient_code='PAC-REAL-99', is_simulated=False, db_path=db_path)
    assert real_res['success']

    # Run simulation
    config = SimulationConfig(
        num_patients=3,
        duration_hours=2,
        measurement_interval_minutes=30,
        random_seed=42,
        simulation_id='SIM-PRESERVE'
    )
    run_simulation(config=config, db_path=db_path)

    # Clear simulation data
    clear_simulation_data(simulation_id='SIM-PRESERVE', db_path=db_path)

    conn = get_connection(db_path)
    try:
        patients = get_all_patients(conn, include_simulated=True)
        assert len(patients) == 1
        assert patients[0].patient_code == 'PAC-REAL-99'
        assert not bool(patients[0].is_simulated)
    finally:
        conn.close()


def test_simulation_creates_patients_with_clinical_fields(db_path):
    """Verify that simulated patients are registered with fictitious name, symptoms, initial diagnosis, and triage level."""
    config = SimulationConfig(
        num_patients=5,
        duration_hours=2,
        measurement_interval_minutes=30,
        random_seed=42,
        simulation_id='SIM-CLINICAL-FIELDS'
    )
    result = run_simulation(config=config, db_path=db_path)
    assert result.get('success') is True

    conn = get_connection(db_path)
    try:
        patients = get_all_patients(conn, include_simulated=True)
        assert len(patients) == 5
        for p in patients:
            assert p.full_name != '', "El paciente simulado debe tener nombre completo ficticio"
            assert p.symptoms != '', "El paciente simulado debe tener síntomas asignados"
            assert p.initial_diagnosis != '', "El paciente simulado debe tener diagnóstico inicial"
            assert p.triage_level in [1, 2, 3, 4, 5], "El nivel de triaje debe estar entre 1 y 5"
    finally:
        conn.close()
