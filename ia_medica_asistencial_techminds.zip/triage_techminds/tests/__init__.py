"""Test package for IA Médica Asistencial."""
