"""Pruebas del motor de alertas (reglas, deduplicación y reconocimiento)."""
from datetime import datetime, timedelta

from config import ALERT_STATUS_ACKNOWLEDGED, ALERT_STATUS_PENDING
from alert_engine import AlertEngine
from database import get_alerts_for_patient, get_connection


def _alerts_of_type(alerts, alert_type):
    return [a for a in alerts if a.alert_type == alert_type]


def _stored_alerts(db_path, patient_id):
    conn = get_connection(db_path)
    try:
        return get_alerts_for_patient(conn, patient_id=patient_id)
    finally:
        conn.close()


def test_alert_engine_initializes_with_default_rules(db_path):
    """El motor arranca con las seis reglas por defecto activas."""
    engine = AlertEngine(db_path=db_path)
    rules = {r['name']: r for r in engine.get_rules_status()}
    expected = {
        'new_measurement', 'value_change', 'incomplete_evaluation',
        'high_score', 'long_wait', 'unacknowledged_alert',
    }
    assert expected.issubset(rules.keys())
    assert all(rules[name]['enabled'] for name in expected)


def test_enable_disable_rules(db_path):
    """Una regla puede desactivarse y reactivarse."""
    engine = AlertEngine(db_path=db_path)
    assert engine.disable_rule('high_score') is True
    status = {r['name']: r['enabled'] for r in engine.get_rules_status()}
    assert status['high_score'] is False

    assert engine.enable_rule('high_score') is True
    status = {r['name']: r['enabled'] for r in engine.get_rules_status()}
    assert status['high_score'] is True


def test_evaluate_new_measurement_structure(registered_patient, sample_measurement_complete, evaluate_measurement):
    """evaluate_new_measurement devuelve evaluación, alertas y cambios."""
    patient_id, _ = registered_patient
    _, outcome = evaluate_measurement(patient_id, sample_measurement_complete)
    assert set(outcome.keys()) >= {'evaluation', 'alerts', 'changes'}
    assert outcome['evaluation'].patient_id == patient_id
    assert outcome['evaluation'].id is not None
    assert outcome['evaluation'].score == 0


def test_unsaved_measurement_is_rejected(registered_patient, sample_measurement_complete, db_path):
    """Una medición sin id (no persistida) se rechaza con un error claro."""
    import pytest
    from models import Measurement

    patient_id, _ = registered_patient
    engine = AlertEngine(db_path=db_path)
    unsaved = Measurement(id=None, patient_id=patient_id, **sample_measurement_complete)
    with pytest.raises(ValueError):
        engine.evaluate_new_measurement(patient_id, unsaved)


def test_new_measurement_generates_informative_alert(registered_patient, sample_measurement_complete, evaluate_measurement):
    """Una medición nueva genera la alerta informativa 'new_measurement' pendiente."""
    patient_id, _ = registered_patient
    _, outcome = evaluate_measurement(patient_id, sample_measurement_complete)
    found = _alerts_of_type(outcome['alerts'], 'new_measurement')
    assert len(found) == 1
    assert found[0].status == ALERT_STATUS_PENDING
    assert found[0].rule_name == 'new_measurement'


def test_critical_values_generate_high_score_alert(registered_patient, sample_measurement_critical, evaluate_measurement):
    """Valores críticos completos generan una alerta 'high_score' pendiente."""
    patient_id, _ = registered_patient
    _, outcome = evaluate_measurement(patient_id, sample_measurement_critical)
    assert outcome['evaluation'].risk_level == 'high'
    found = _alerts_of_type(outcome['alerts'], 'high_score')
    assert len(found) == 1
    assert found[0].status == ALERT_STATUS_PENDING
    assert found[0].evaluation_id == outcome['evaluation'].id


def test_incomplete_data_generates_incomplete_evaluation_alert(registered_patient, sample_measurement_incomplete, evaluate_measurement):
    """Datos obligatorios ausentes generan 'incomplete_evaluation' y no producen puntuación."""
    patient_id, _ = registered_patient
    _, outcome = evaluate_measurement(patient_id, sample_measurement_incomplete)
    assert outcome['evaluation'].score is None
    assert outcome['evaluation'].completeness_status == 'incompleto'
    assert len(_alerts_of_type(outcome['alerts'], 'incomplete_evaluation')) == 1
    assert _alerts_of_type(outcome['alerts'], 'high_score') == []


def test_duplicate_alerts_prevented_within_window(registered_patient, sample_measurement_critical, evaluate_measurement, db_path):
    """Una segunda medición crítica inmediata no duplica la alerta 'high_score'."""
    patient_id, _ = registered_patient
    _, first = evaluate_measurement(patient_id, sample_measurement_critical)
    assert len(_alerts_of_type(first['alerts'], 'high_score')) == 1

    _, second = evaluate_measurement(patient_id, sample_measurement_critical)
    assert _alerts_of_type(second['alerts'], 'high_score') == []
    stored = _alerts_of_type(_stored_alerts(db_path, patient_id), 'high_score')
    assert len(stored) == 1


def test_acknowledge_alert(registered_patient, sample_measurement_critical, evaluate_measurement):
    """Una alerta pendiente puede reconocerse y deja de aparecer como pendiente."""
    patient_id, _ = registered_patient
    _, outcome = evaluate_measurement(patient_id, sample_measurement_critical)
    target = _alerts_of_type(outcome['alerts'], 'high_score')[0]

    engine = evaluate_measurement.engine
    assert engine.acknowledge_alert(target.id) is True
    pending_ids = [a.id for a in engine.get_pending_alerts(patient_id=patient_id)]
    assert target.id not in pending_ids


def test_acknowledged_alert_is_not_regenerated_or_reopened(registered_patient, sample_measurement_critical, evaluate_measurement, db_path):
    """Tras reconocer una alerta, una medición posterior no la reabre ni la duplica."""
    patient_id, _ = registered_patient
    _, outcome = evaluate_measurement(patient_id, sample_measurement_critical)
    target = _alerts_of_type(outcome['alerts'], 'high_score')[0]
    evaluate_measurement.engine.acknowledge_alert(target.id)

    evaluate_measurement(patient_id, sample_measurement_critical)

    stored = _alerts_of_type(_stored_alerts(db_path, patient_id), 'high_score')
    assert len(stored) == 1
    assert stored[0].status == ALERT_STATUS_ACKNOWLEDGED


def test_alert_history_preserved(registered_patient, sample_measurement_critical, evaluate_measurement, db_path):
    """Reconocer una alerta no la elimina: se conserva con su fecha de reconocimiento."""
    patient_id, _ = registered_patient
    _, outcome = evaluate_measurement(patient_id, sample_measurement_critical)
    target = _alerts_of_type(outcome['alerts'], 'high_score')[0]
    evaluate_measurement.engine.acknowledge_alert(target.id)

    found = [a for a in _stored_alerts(db_path, patient_id) if a.id == target.id]
    assert len(found) == 1
    assert found[0].status == ALERT_STATUS_ACKNOWLEDGED
    assert found[0].acknowledged_at is not None


def test_disabled_rule_does_not_fire(registered_patient, sample_measurement_critical, evaluate_measurement):
    """Con la regla 'high_score' desactivada no se genera esa alerta."""
    patient_id, _ = registered_patient
    evaluate_measurement.engine.disable_rule('high_score')
    _, outcome = evaluate_measurement(patient_id, sample_measurement_critical)
    assert _alerts_of_type(outcome['alerts'], 'high_score') == []


def test_value_change_compares_against_previous_measurement(
    registered_patient, sample_measurement_complete, sample_measurement_critical, evaluate_measurement
):
    """El cambio se calcula contra la medición inmediatamente anterior, no contra la primera."""
    patient_id, _ = registered_patient
    base = datetime.now() - timedelta(minutes=30)
    stamp = lambda minutes: (base + timedelta(minutes=minutes)).isoformat()

    _, first = evaluate_measurement(patient_id, sample_measurement_complete, recorded_at=stamp(0))
    assert first['changes'] == []

    _, second = evaluate_measurement(patient_id, sample_measurement_critical, recorded_at=stamp(10))
    assert len(second['changes']) > 0
    assert len(_alerts_of_type(second['alerts'], 'value_change')) == 1

    # Tercera medición idéntica a la segunda: no hay cambios respecto a la anterior.
    _, third = evaluate_measurement(patient_id, sample_measurement_critical, recorded_at=stamp(20))
    assert third['changes'] == []
