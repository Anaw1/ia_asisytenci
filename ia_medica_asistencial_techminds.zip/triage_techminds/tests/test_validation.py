"""Tests for data validation module."""
import pytest
from datetime import datetime, timedelta
from config import DATE_FORMAT, ADMIN_STATUSES, CONSCIOUSNESS_LEVELS
from validation import (
    ValidationResult,
    validate_patient_code,
    validate_patient_name,
    validate_arrival_datetime,
    validate_measurement,
    validate_measurement_completeness,
    validate_symptoms,
    validate_initial_diagnosis,
    validate_triage_level,
    validate_patient_admission,
    validate_administrative_status,
    validate_simulation_config,
)


def test_validate_patient_code_valid():
    """Verify that correctly formatted patient codes are accepted."""
    valid_codes = ['PAC-001', 'PAC-2024-001', 'P-1234', 'ABCDEFGHIJ-12345678', 'MED-99']
    for code in valid_codes:
        result = validate_patient_code(code)
        assert isinstance(result, ValidationResult)
        assert result.is_valid, f"Expected {code} to be valid, got errors: {result.errors}"
        assert len(result.errors) == 0


def test_validate_patient_code_empty_and_none():
    """Verify that empty or None patient codes are rejected."""
    for empty_val in ['', None, '   ']:
        result = validate_patient_code(empty_val)
        assert not result.is_valid
        assert len(result.errors) > 0


def test_validate_patient_code_too_short():
    """Verify that codes shorter than minimum length (3 chars) are rejected."""
    short_codes = ['P', 'PA', '12']
    for code in short_codes:
        result = validate_patient_code(code)
        assert not result.is_valid
        assert any('longitud' in err.lower() or 'caracter' in err.lower() or 'código' in err.lower() or 'corta' in err.lower() for err in result.errors) or len(result.errors) > 0


def test_validate_patient_code_too_long():
    """Verify that codes exceeding maximum length (20 chars) are rejected."""
    long_code = 'P' * 25
    result = validate_patient_code(long_code)
    assert not result.is_valid
    assert len(result.errors) > 0


def test_validate_patient_code_special_characters():
    """Verify that patient codes with invalid symbols or spaces are rejected."""
    invalid_codes = ['PAC@123', 'PAC#001', 'PAC$99', 'PAC!123', 'PAC 001', 'PAC.123*']
    for code in invalid_codes:
        result = validate_patient_code(code)
        assert not result.is_valid
        assert len(result.errors) > 0


def test_validate_arrival_datetime_valid():
    """Verify that valid ISO-formatted and current or past arrival dates are accepted."""
    now_str = datetime.now().strftime(DATE_FORMAT)
    past_str = (datetime.now() - timedelta(hours=2)).strftime(DATE_FORMAT)
    
    for valid_date in [now_str, past_str]:
        result = validate_arrival_datetime(valid_date)
        assert isinstance(result, ValidationResult)
        assert result.is_valid, f"Expected {valid_date} to be valid, got errors: {result.errors}"
        assert len(result.errors) == 0


def test_validate_arrival_datetime_future_date():
    """Verify that future arrival datetimes are rejected."""
    future_str = (datetime.now() + timedelta(days=2)).strftime(DATE_FORMAT)
    result = validate_arrival_datetime(future_str)
    assert not result.is_valid
    assert len(result.errors) > 0


def test_validate_arrival_datetime_invalid_format():
    """Verify that malformed or impossible datetimes are rejected."""
    invalid_dates = ['15/01/2024', 'invalid-datetime', '2024-02-31 10:00:00', '', None]
    for bad_date in invalid_dates:
        result = validate_arrival_datetime(bad_date)
        assert not result.is_valid
        assert len(result.errors) > 0


def test_validate_measurement_valid_complete(sample_measurement_complete):
    """Verify that a complete measurement within normal physiological bounds is valid."""
    result = validate_measurement(sample_measurement_complete)
    assert isinstance(result, ValidationResult)
    assert result.is_valid
    assert len(result.errors) == 0


def test_validate_measurement_out_of_range_rejected():
    """Verify that physically impossible or out-of-range measurements are rejected."""
    invalid_measurements = [
        {'respiratory_rate': -5},
        {'respiratory_rate': 120},
        {'oxygen_saturation': -1},
        {'oxygen_saturation': 105},
        {'systolic_blood_pressure': -10},
        {'systolic_blood_pressure': 400},
        {'heart_rate': -5},
        {'heart_rate': 350},
        {'temperature': 20.0},
        {'temperature': 50.0},
        {'consciousness_status': 'Z'},
    ]
    for data in invalid_measurements:
        full_data = {
            'respiratory_rate': 18,
            'oxygen_saturation': 98,
            'supplemental_oxygen': False,
            'systolic_blood_pressure': 120,
            'heart_rate': 75,
            'temperature': 37.0,
            'consciousness_status': 'A'
        }
        full_data.update(data)
        result = validate_measurement(full_data)
        assert not result.is_valid, f"Data {data} should have failed validation"
        assert len(result.errors) > 0


def test_validate_measurement_atypical_values_warning():
    """Verify that extreme/atypical clinical values produce warnings."""
    atypical_data = {
        'respiratory_rate': 29,
        'oxygen_saturation': 86,
        'supplemental_oxygen': True,
        'systolic_blood_pressure': 80,
        'heart_rate': 135,
        'temperature': 39.4,
        'consciousness_status': 'V'
    }
    result = validate_measurement(atypical_data)
    assert result.is_valid
    assert len(result.warnings) > 0


def test_validate_measurement_missing_fields_partial(sample_measurement_incomplete):
    """Verify that missing fields in partial measurements are handled appropriately."""
    result = validate_measurement(sample_measurement_incomplete)
    assert isinstance(result, ValidationResult)
    # Partial data may be valid for individual params but incomplete for NEWS2
    assert result.is_valid


def test_validate_measurement_completeness_complete(sample_measurement_complete):
    """Verify completeness validation returns true with no missing parameters for full data."""
    is_complete, missing = validate_measurement_completeness(sample_measurement_complete)
    assert is_complete is True
    assert len(missing) == 0


def test_validate_measurement_completeness_incomplete(sample_measurement_incomplete):
    """Verify completeness validation returns false and identifies missing parameters."""
    is_complete, missing = validate_measurement_completeness(sample_measurement_incomplete)
    assert is_complete is False
    assert len(missing) > 0
    # validate_measurement_completeness returns Spanish names
    missing_str = ' '.join(missing).lower()
    assert 'saturación' in missing_str or 'oxígeno' in missing_str
    assert 'temperatura' in missing_str


def test_validate_administrative_status_valid():
    """Verify that all configured administrative statuses are recognized as valid."""
    for status in ADMIN_STATUSES.keys():
        result = validate_administrative_status(status)
        assert isinstance(result, ValidationResult)
        assert result.is_valid
        assert len(result.errors) == 0


def test_validate_administrative_status_invalid():
    """Verify that unregistered administrative statuses are rejected."""
    invalid_statuses = ['desconocido', 'triaged', 'waiting', '', None, 123]
    for status in invalid_statuses:
        result = validate_administrative_status(status)
        assert not result.is_valid
        assert len(result.errors) > 0


def test_validate_simulation_config_valid():
    """Verify that valid simulation configuration arguments pass validation."""
    result = validate_simulation_config(
        num_patients=10,
        duration_hours=4,
        measurement_interval=30,
        seed=42
    )
    assert isinstance(result, ValidationResult)
    assert result.is_valid
    assert len(result.errors) == 0


def test_validate_simulation_config_invalid():
    """Verify that invalid simulation parameters are rejected."""
    test_cases = [
        (0, 4, 30, 42),       # num_patients <= 0
        (-5, 4, 30, 42),      # negative patients
        (10, 0, 30, 42),      # duration_hours <= 0
        (10, -2, 30, 42),     # negative duration
        (10, 4, 0, 42),       # interval <= 0
        (10, 4, -10, 42),     # negative interval
    ]
    for num_p, dur_h, interval, seed in test_cases:
        result = validate_simulation_config(
            num_patients=num_p,
            duration_hours=dur_h,
            measurement_interval=interval,
            seed=seed
        )
        assert not result.is_valid
        assert len(result.errors) > 0


def test_validate_patient_name_valid():
    """Verify that valid human names are accepted."""
    valid_names = [
        'Carlos Gómez',
        'María Fernanda Torres',
        'José Peña (Ficticio)',
        'Ana-Sofía Morales',
        'Dr. Juan Pérez',
    ]
    for name in valid_names:
        res = validate_patient_name(name, required=True)
        assert res.is_valid, f"Expected valid for {name}, got {res.errors}"
        assert res.cleaned_data['full_name'] == name


def test_validate_patient_name_invalid():
    """Verify that empty, non-string or malformed names are rejected."""
    invalid_cases = ['', '   ', None, 12345, 'A', 'Carlos@Gomez#123']
    for val in invalid_cases:
        res = validate_patient_name(val, required=True)
        assert not res.is_valid
        assert len(res.errors) > 0


def test_validate_symptoms_and_diagnosis():
    """Verify validation of clinical symptoms and initial diagnosis."""
    # Symptoms
    sym_res = validate_symptoms("Dolor torácico opresivo de 2 horas", required=True)
    assert sym_res.is_valid
    assert "Dolor torácico" in sym_res.cleaned_data['symptoms']

    sym_empty = validate_symptoms("", required=True)
    assert not sym_empty.is_valid

    # Initial diagnosis
    dx_res = validate_initial_diagnosis("Sospecha de síndrome coronario agudo", required=True)
    assert dx_res.is_valid
    assert "síndrome coronario" in dx_res.cleaned_data['initial_diagnosis']

    dx_empty = validate_initial_diagnosis("", required=True)
    assert not dx_empty.is_valid


def test_validate_triage_level_valid():
    """Verify that triage levels 1 to 5 are accepted."""
    for lvl in [1, 2, 3, 4, 5, '1', '5']:
        res = validate_triage_level(lvl, required=True)
        assert res.is_valid
        assert res.cleaned_data['triage_level'] in (1, 2, 3, 4, 5)


def test_validate_triage_level_invalid():
    """Verify that invalid triage levels outside 1-5 or malformed values are rejected."""
    for lvl in [0, 6, -1, 99, 'invalido', 'Nivel I', 3.5]:
        res = validate_triage_level(lvl, required=True)
        assert not res.is_valid
        assert len(res.errors) > 0


def test_validate_patient_admission_complete():
    """Verify comprehensive admission validation."""
    data = {
        'patient_code': 'PAC-ADMIT-01',
        'full_name': 'Mario Casas (Ficticio)',
        'arrival_at': datetime.now().isoformat(),
        'symptoms': 'Fiebre alta y cefalea persistente',
        'initial_diagnosis': 'Síndrome febril agudo en estudio',
        'triage_level': 2,
    }
    res = validate_patient_admission(data, require_clinical=True)
    assert res.is_valid
    assert res.cleaned_data['full_name'] == 'Mario Casas (Ficticio)'
    assert res.cleaned_data['triage_level'] == 2

