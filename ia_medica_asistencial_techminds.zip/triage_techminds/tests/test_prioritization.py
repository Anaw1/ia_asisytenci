"""Pruebas de la cola administrativa simulada (orden, razones y actualización)."""
from datetime import datetime, timedelta

from config import DATE_FORMAT
from models import Alert, Measurement
from clinical_scoring import calculate_news2, create_evaluation_from_news2
from patient_service import register_patient, update_status
from prioritization import build_queue, calculate_priority_score, format_queue_for_display


def _minutes_ago(minutes):
    return (datetime.now() - timedelta(minutes=minutes)).strftime(DATE_FORMAT)


def _codes(queue):
    return [entry.patient.patient_code for entry in queue]


def test_empty_queue_returns_empty_list(db_path):
    """Sin pacientes registrados la cola está vacía."""
    assert build_queue(db_path=db_path) == []


def test_single_patient_gets_position_one(db_path):
    """Un único paciente en espera ocupa la posición 1."""
    assert register_patient(patient_code='PAC-SINGLE-01', db_path=db_path)['success']
    queue = build_queue(db_path=db_path)
    assert len(queue) == 1
    assert queue[0].position == 1
    assert queue[0].patient.patient_code == 'PAC-SINGLE-01'


def test_patient_with_pending_alerts_is_ahead_of_later_arrival(
    db_path, sample_measurement_complete, sample_measurement_critical, evaluate_measurement
):
    """El paciente con alertas pendientes y NEWS2 alto queda antes aunque haya llegado después."""
    normal = register_patient(patient_code='PAC-NORMAL-01', arrival_at=_minutes_ago(20), db_path=db_path)
    evaluate_measurement(normal['patient_id'], sample_measurement_complete)

    critical = register_patient(patient_code='PAC-CRITICAL-01', arrival_at=_minutes_ago(10), db_path=db_path)
    evaluate_measurement(critical['patient_id'], sample_measurement_critical)

    queue = build_queue(db_path=db_path)
    assert _codes(queue) == ['PAC-CRITICAL-01', 'PAC-NORMAL-01']
    assert queue[0].pending_alerts > queue[1].pending_alerts


def test_higher_news2_score_yields_higher_priority_score(sample_patient, sample_measurement_complete, sample_measurement_critical):
    """Con el mismo tiempo de espera y sin alertas, un NEWS2 alto suma más puntos de prioridad."""
    now = datetime.now().strftime(DATE_FORMAT)
    low_eval = create_evaluation_from_news2(
        1, 1, calculate_news2(Measurement(id=1, patient_id=1, recorded_at=now, **sample_measurement_complete))
    )
    high_eval = create_evaluation_from_news2(
        1, 2, calculate_news2(Measurement(id=2, patient_id=1, recorded_at=now, **sample_measurement_critical))
    )

    score_low, _ = calculate_priority_score(sample_patient, low_eval, [], wait_time_minutes=30)
    score_high, reasons_high = calculate_priority_score(sample_patient, high_eval, [], wait_time_minutes=30)

    assert score_high > score_low
    assert any('NEWS2' in reason for reason in reasons_high)


def test_longer_wait_time_increases_priority(db_path, sample_measurement_complete, evaluate_measurement):
    """A igual estado clínico, quien lleva más tiempo esperando va primero."""
    old = register_patient(patient_code='PAC-WAIT-OLD', arrival_at=_minutes_ago(120), db_path=db_path)
    evaluate_measurement(old['patient_id'], sample_measurement_complete)
    new = register_patient(patient_code='PAC-WAIT-NEW', arrival_at=_minutes_ago(10), db_path=db_path)
    evaluate_measurement(new['patient_id'], sample_measurement_complete)

    assert _codes(build_queue(db_path=db_path)) == ['PAC-WAIT-OLD', 'PAC-WAIT-NEW']


def test_queue_updates_after_new_measurement(
    db_path, sample_measurement_complete, sample_measurement_critical, evaluate_measurement
):
    """Una nueva medición crítica reordena la cola."""
    stable = register_patient(patient_code='PAC-STABLE-02', arrival_at=_minutes_ago(60), db_path=db_path)
    evaluate_measurement(stable['patient_id'], sample_measurement_complete)
    deteriorating = register_patient(patient_code='PAC-DETER-01', arrival_at=_minutes_ago(30), db_path=db_path)
    evaluate_measurement(deteriorating['patient_id'], sample_measurement_complete)

    assert _codes(build_queue(db_path=db_path)) == ['PAC-STABLE-02', 'PAC-DETER-01']

    evaluate_measurement(
        deteriorating['patient_id'], sample_measurement_critical,
        recorded_at=datetime.now().isoformat(),
    )
    assert _codes(build_queue(db_path=db_path)) == ['PAC-DETER-01', 'PAC-STABLE-02']


def test_patient_leaves_queue_when_status_changes_to_atendido(db_path):
    """Un paciente 'atendido' sale de la cola de espera."""
    first = register_patient(patient_code='PAC-SERVED-01', db_path=db_path)
    register_patient(patient_code='PAC-WAIT-02', db_path=db_path)
    assert len(build_queue(db_path=db_path)) == 2

    update_status(first['patient_id'], 'atendido', db_path=db_path)

    assert _codes(build_queue(db_path=db_path)) == ['PAC-WAIT-02']


def test_patient_without_evaluation_is_listed_with_data_needed_reason(db_path):
    """Un paciente sin evaluación no se oculta ni se desprioriza: se lista con su razón."""
    register_patient(patient_code='PAC-NOEVAL-01', db_path=db_path)
    queue = build_queue(db_path=db_path)
    assert len(queue) == 1
    assert any('incompleta o pendiente' in reason for reason in queue[0].reasons)


def test_calculate_priority_score_returns_spanish_reasons(sample_patient, sample_measurement_critical):
    """Las razones del orden están en español y explican cada componente."""
    now = datetime.now().strftime(DATE_FORMAT)
    measurement = Measurement(id=1, patient_id=1, recorded_at=now, **sample_measurement_critical)
    evaluation = create_evaluation_from_news2(1, 1, calculate_news2(measurement))
    alert = Alert(
        id=1, patient_id=1, evaluation_id=None, created_at=now, alert_type='high_score',
        reason='Puntuación NEWS2 alta detectada', status='pendiente', rule_name='high_score',
    )

    score, reasons = calculate_priority_score(sample_patient, evaluation, [alert], wait_time_minutes=45)

    assert score > 0
    reasons_text = ' '.join(reasons).lower()
    assert 'alerta' in reasons_text
    assert 'news2' in reasons_text
    assert 'espera' in reasons_text


def test_format_queue_for_display_keys(db_path, sample_measurement_complete, evaluate_measurement):
    """La tabla para la interfaz contiene las columnas administrativas y clínicas definidas."""
    patient = register_patient(
        patient_code='PAC-DISPLAY-01',
        full_name='Sofía Vergara (Ficticio)',
        symptoms='Cefalea moderada',
        initial_diagnosis='Cefalea tensional',
        triage_level=4,
        db_path=db_path,
    )
    evaluate_measurement(patient['patient_id'], sample_measurement_complete)

    rows = format_queue_for_display(build_queue(db_path=db_path))

    assert len(rows) == 1
    assert list(rows[0].keys()) == [
        'Posición', 'Código', 'Nombre', 'Triaje', 'Tiempo espera', 'Última evaluación',
        'Alertas pendientes', 'Síntomas', 'Diagnóstico inicial', 'Puntuación prioridad', 'Razón del orden',
    ]
    assert rows[0]['Posición'] == 1
    assert rows[0]['Código'] == 'PAC-DISPLAY-01'
    assert rows[0]['Nombre'] == 'Sofía Vergara (Ficticio)'
    assert 'Nivel IV' in rows[0]['Triaje']
    assert rows[0]['Síntomas'] == 'Cefalea moderada'
    assert rows[0]['Diagnóstico inicial'] == 'Cefalea tensional'


def test_triage_level_increases_priority_score():
    """El nivel de triaje profesional aporta ponderación coherente a la prioridad administrativa."""
    from models import Patient

    p_triage1 = Patient(patient_code='P1', triage_level=1)
    p_triage2 = Patient(patient_code='P2', triage_level=2)
    p_triage3 = Patient(patient_code='P3', triage_level=3)
    p_triage4 = Patient(patient_code='P4', triage_level=4)
    p_triage5 = Patient(patient_code='P5', triage_level=5)

    s1, r1 = calculate_priority_score(p_triage1, None, [], 0)
    s2, r2 = calculate_priority_score(p_triage2, None, [], 0)
    s3, r3 = calculate_priority_score(p_triage3, None, [], 0)
    s4, r4 = calculate_priority_score(p_triage4, None, [], 0)
    s5, r5 = calculate_priority_score(p_triage5, None, [], 0)

    # Nivel 1 (Reanimación) > Nivel 2 > Nivel 3 > Nivel 4 > Nivel 5
    assert s1 > s2 > s3 > s4 > s5
    assert any('120 pts' in r for r in r1)
    assert any('90 pts' in r for r in r2)
    assert any('50 pts' in r for r in r3)
    assert any('20 pts' in r for r in r4)

