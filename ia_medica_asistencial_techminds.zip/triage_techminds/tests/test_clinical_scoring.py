"""Tests for clinical scoring module (NEWS2 specification)."""
import pytest
from datetime import datetime
from config import DATE_FORMAT
from models import Measurement, Evaluation
from clinical_scoring import (
    NEWS2ParameterResult,
    NEWS2Result,
    score_respiratory_rate,
    score_oxygen_saturation_scale1,
    score_oxygen_saturation_scale2,
    score_supplemental_oxygen,
    score_systolic_bp,
    score_heart_rate,
    score_consciousness,
    score_temperature,
    calculate_news2,
    detect_measurement_changes,
    create_evaluation_from_news2,
)


def test_score_respiratory_rate_boundaries():
    """Verify Royal College of Physicians boundaries for respiratory rate."""
    cases = [
        (8, 3),
        (9, 1),
        (11, 1),
        (12, 0),
        (20, 0),
        (21, 2),
        (24, 2),
        (25, 3),
    ]
    for rate, expected_score in cases:
        res = score_respiratory_rate(rate)
        assert isinstance(res, NEWS2ParameterResult)
        assert res.score == expected_score, f"RR {rate}: expected {expected_score}, got {res.score}"
        assert res.parameter_name == 'Frecuencia respiratoria'


def test_score_oxygen_saturation_scale1_boundaries():
    """Verify Royal College of Physicians boundaries for SpO2 Scale 1."""
    cases = [
        (91, 3),
        (92, 2),
        (93, 2),
        (94, 1),
        (95, 1),
        (96, 0),
        (98, 0),
        (100, 0),
    ]
    for spo2, expected_score in cases:
        res = score_oxygen_saturation_scale1(spo2)
        assert isinstance(res, NEWS2ParameterResult)
        assert res.score == expected_score, f"SpO2 {spo2}: expected {expected_score}, got {res.score}"
        assert res.parameter_name == 'Saturación de oxígeno (Escala 1)'


def test_score_oxygen_saturation_scale2_on_oxygen():
    """Verify SpO2 Scale 2 for hypercapnic respiratory failure on supplemental oxygen."""
    cases = [
        (83, 3),
        (84, 2),
        (85, 2),
        (86, 1),
        (87, 1),
        (88, 0),
        (92, 0),
        (93, 1),
        (94, 1),
        (95, 2),
        (96, 2),
        (97, 3),
    ]
    for spo2, expected_score in cases:
        res = score_oxygen_saturation_scale2(spo2, on_oxygen=True)
        assert isinstance(res, NEWS2ParameterResult)
        assert res.score == expected_score, f"Scale2 on O2 SpO2 {spo2}: expected {expected_score}, got {res.score}"


def test_score_oxygen_saturation_scale2_room_air():
    """Verify SpO2 Scale 2 on room air (no supplemental oxygen)."""
    cases = [
        (83, 3),
        (85, 2),
        (87, 1),
        (88, 0),
        (92, 0),
        (94, 0),
        (98, 0),
    ]
    for spo2, expected_score in cases:
        res = score_oxygen_saturation_scale2(spo2, on_oxygen=False)
        assert isinstance(res, NEWS2ParameterResult)
        assert res.score == expected_score, f"Scale2 room air SpO2 {spo2}: expected {expected_score}, got {res.score}"


def test_score_supplemental_oxygen():
    """Verify score for supplemental oxygen administration: 0 for Air, 2 for Oxygen."""
    res_false = score_supplemental_oxygen(False)
    assert isinstance(res_false, NEWS2ParameterResult)
    assert res_false.score == 0

    res_true = score_supplemental_oxygen(True)
    assert isinstance(res_true, NEWS2ParameterResult)
    assert res_true.score == 2


def test_score_systolic_bp_boundaries():
    """Verify Royal College of Physicians boundaries for systolic blood pressure."""
    cases = [
        (90, 3),
        (91, 2),
        (100, 2),
        (101, 1),
        (110, 1),
        (111, 0),
        (150, 0),
        (219, 0),
        (220, 3),
        (230, 3),
    ]
    for sbp, expected_score in cases:
        res = score_systolic_bp(sbp)
        assert isinstance(res, NEWS2ParameterResult)
        assert res.score == expected_score, f"SBP {sbp}: expected {expected_score}, got {res.score}"
        assert res.parameter_name == 'Presión arterial sistólica'


def test_score_heart_rate_boundaries():
    """Verify Royal College of Physicians boundaries for heart rate."""
    cases = [
        (40, 3),
        (41, 1),
        (50, 1),
        (51, 0),
        (75, 0),
        (90, 0),
        (91, 1),
        (110, 1),
        (111, 2),
        (130, 2),
        (131, 3),
        (150, 3),
    ]
    for hr, expected_score in cases:
        res = score_heart_rate(hr)
        assert isinstance(res, NEWS2ParameterResult)
        assert res.score == expected_score, f"HR {hr}: expected {expected_score}, got {res.score}"
        assert res.parameter_name == 'Frecuencia cardíaca'


def test_score_consciousness_levels():
    """Verify Alert is 0; Voice, Pain, Unresponsive (ACVPU) are 3."""
    assert score_consciousness('A').score == 0
    assert score_consciousness('V').score == 3
    assert score_consciousness('P').score == 3
    assert score_consciousness('U').score == 3


def test_score_temperature_boundaries():
    """Verify Royal College of Physicians boundaries for temperature."""
    cases = [
        (35.0, 3),
        (35.1, 1),
        (36.0, 1),
        (36.1, 0),
        (37.5, 0),
        (38.0, 0),
        (38.1, 1),
        (39.0, 1),
        (39.1, 2),
        (40.0, 2),
    ]
    for temp, expected_score in cases:
        res = score_temperature(temp)
        assert isinstance(res, NEWS2ParameterResult)
        assert res.score == expected_score, f"Temp {temp}: expected {expected_score}, got {res.score}"
        assert res.parameter_name == 'Temperatura corporal'


def test_calculate_news2_normal_patient(sample_measurement_complete):
    """Verify complete normal measurement yields score 0 and low risk."""
    now = datetime.now().strftime(DATE_FORMAT)
    measurement = Measurement(
        id=1,
        patient_id=1,
        recorded_at=now,
        **sample_measurement_complete
    )
    result = calculate_news2(measurement)
    assert isinstance(result, NEWS2Result)
    assert result.total_score == 0
    assert result.risk_level.lower() == 'low' or 'bajo' in result.risk_label.lower()
    assert result.is_complete is True
    assert len(result.missing_parameters) == 0


def test_calculate_news2_critical_patient(sample_measurement_critical):
    """Verify critical measurement yields high score (>=7) and high risk."""
    now = datetime.now().strftime(DATE_FORMAT)
    measurement = Measurement(
        id=2,
        patient_id=1,
        recorded_at=now,
        **sample_measurement_critical
    )
    result = calculate_news2(measurement)
    assert isinstance(result, NEWS2Result)
    # Expected: RR=28(3) + SpO2=88(3) + O2=True(2) + SBP=85(3) + HR=140(3) + Temp=39.5(2) + Con=V(3) = 19
    assert result.total_score >= 7
    assert result.risk_level.lower() == 'high' or 'alto' in result.risk_label.lower()
    assert result.is_complete is True


def test_calculate_news2_medium_risk():
    """Verify NEWS2 score of 5 or 6 maps to medium risk level."""
    now = datetime.now().strftime(DATE_FORMAT)
    # Target total = 5 (e.g. SBP=105 -> 1, HR=115 -> 2, O2=True -> 2, others normal)
    measurement = Measurement(
        id=3,
        patient_id=1,
        recorded_at=now,
        respiratory_rate=18,          # 0
        oxygen_saturation=97,         # 0
        supplemental_oxygen=True,     # 2
        systolic_blood_pressure=105,  # 1
        heart_rate=115,               # 2
        temperature=37.0,             # 0
        consciousness_status='A'      # 0
    )
    result = calculate_news2(measurement)
    assert result.total_score == 5
    assert result.risk_level.lower() in ['medium', 'medio']


def test_calculate_news2_single_parameter_score_three_trigger():
    """Verify a single score of 3 triggers low-medium risk even if total is < 5."""
    now = datetime.now().strftime(DATE_FORMAT)
    # Consciousness 'V' gives score 3, others normal. Total = 3
    measurement = Measurement(
        id=4,
        patient_id=1,
        recorded_at=now,
        respiratory_rate=18,          # 0
        oxygen_saturation=97,         # 0
        supplemental_oxygen=False,    # 0
        systolic_blood_pressure=120,  # 0
        heart_rate=75,                # 0
        temperature=37.0,             # 0
        consciousness_status='V'      # 3
    )
    result = calculate_news2(measurement)
    assert result.total_score == 3
    assert result.risk_level.lower() in ['low_medium', 'low-medium', 'medio_bajo', 'medium']


def test_calculate_news2_incomplete_measurement(sample_measurement_incomplete):
    """Verify incomplete measurement returns is_complete=False and missing parameters."""
    now = datetime.now().strftime(DATE_FORMAT)
    measurement = Measurement(
        id=5,
        patient_id=1,
        recorded_at=now,
        **sample_measurement_incomplete
    )
    result = calculate_news2(measurement)
    assert isinstance(result, NEWS2Result)
    assert result.is_complete is False
    assert len(result.missing_parameters) > 0
    assert 'Saturación de oxígeno' in result.missing_parameters
    assert 'Temperatura corporal' in result.missing_parameters


def test_calculate_news2_all_missing_parameters():
    """Verify an empty measurement reports all parameters missing."""
    now = datetime.now().strftime(DATE_FORMAT)
    measurement = Measurement(
        id=6,
        patient_id=1,
        recorded_at=now,
        respiratory_rate=None,
        oxygen_saturation=None,
        supplemental_oxygen=None,
        systolic_blood_pressure=None,
        heart_rate=None,
        temperature=None,
        consciousness_status=None
    )
    result = calculate_news2(measurement)
    assert result.is_complete is False
    assert len(result.missing_parameters) == 7


def test_detect_measurement_changes_no_change(sample_measurement_complete):
    """Verify detecting changes between identical measurements returns no changes."""
    now = datetime.now().strftime(DATE_FORMAT)
    m1 = Measurement(id=1, patient_id=1, recorded_at=now, **sample_measurement_complete)
    m2 = Measurement(id=2, patient_id=1, recorded_at=now, **sample_measurement_complete)
    changes = detect_measurement_changes(current=m2, previous=m1)
    assert isinstance(changes, list)
    assert len(changes) == 0


def test_detect_measurement_changes_significant(sample_measurement_complete):
    """Verify significant vital sign shifts are detected."""
    now = datetime.now().strftime(DATE_FORMAT)
    m1 = Measurement(id=1, patient_id=1, recorded_at=now, **sample_measurement_complete)
    
    modified = dict(sample_measurement_complete)
    modified['heart_rate'] = 135
    modified['systolic_blood_pressure'] = 85
    modified['respiratory_rate'] = 28
    m2 = Measurement(id=2, patient_id=1, recorded_at=now, **modified)

    changes = detect_measurement_changes(current=m2, previous=m1)
    assert isinstance(changes, list)
    assert len(changes) > 0
    param_names = [c.get('parameter', c.get('parameter_name')) for c in changes]
    assert 'Frecuencia cardíaca' in param_names
    assert 'Presión arterial sistólica' in param_names
    assert 'Frecuencia respiratoria' in param_names


def test_detect_measurement_changes_first_measurement(sample_measurement_complete):
    """Verify detect_measurement_changes handles a None previous measurement safely."""
    now = datetime.now().strftime(DATE_FORMAT)
    m = Measurement(id=1, patient_id=1, recorded_at=now, **sample_measurement_complete)
    changes = detect_measurement_changes(current=m, previous=None)
    assert isinstance(changes, list)


def test_create_evaluation_from_news2(sample_measurement_complete):
    """Verify Evaluation object is correctly synthesized from NEWS2 result."""
    now = datetime.now().strftime(DATE_FORMAT)
    m = Measurement(id=10, patient_id=42, recorded_at=now, **sample_measurement_complete)
    news2_res = calculate_news2(m)
    
    eval_obj = create_evaluation_from_news2(
        patient_id=42,
        measurement_id=10,
        news2_result=news2_res
    )
    assert isinstance(eval_obj, Evaluation)
    assert eval_obj.patient_id == 42
    assert eval_obj.measurement_id == 10
    assert eval_obj.score == news2_res.total_score
    assert eval_obj.risk_level == news2_res.risk_level
    assert eval_obj.completeness_status in ['completa', 'completo', 'complete', 'True']


def test_news2_parameter_result_structure():
    """Verify NEWS2ParameterResult attributes and types."""
    res = NEWS2ParameterResult(
        parameter_name='respiratory_rate',
        value=22,
        score=2,
        explanation='Frecuencia respiratoria elevada (21-24 rpm)'
    )
    assert res.parameter_name == 'respiratory_rate'
    assert res.value == 22
    assert res.score == 2
    assert isinstance(res.explanation, str)


def test_news2_result_structure(sample_measurement_complete):
    """Verify NEWS2Result structure contains all required fields."""
    now = datetime.now().strftime(DATE_FORMAT)
    m = Measurement(id=1, patient_id=1, recorded_at=now, **sample_measurement_complete)
    res = calculate_news2(m)
    assert hasattr(res, 'total_score')
    assert hasattr(res, 'parameter_results')
    assert hasattr(res, 'risk_level')
    assert hasattr(res, 'risk_label')
    assert hasattr(res, 'is_complete')
    assert hasattr(res, 'missing_parameters')
    assert hasattr(res, 'explanation')
    assert hasattr(res, 'scale_used')


def _spo2_measurement(spo2_scale):
    """Medición con SpO2 97% y oxígeno suplementario; el resto de parámetros normales."""
    return Measurement(
        id=10,
        patient_id=1,
        recorded_at=datetime.now().strftime(DATE_FORMAT),
        respiratory_rate=18,
        oxygen_saturation=97,
        supplemental_oxygen=True,
        systolic_blood_pressure=120,
        heart_rate=75,
        temperature=37.0,
        consciousness_status='A',
        spo2_scale=spo2_scale,
    )


def test_spo2_scale_1_is_used_by_default_even_with_oxygen():
    """NEWS2 usa la Escala 1 por defecto: SpO2 97% con oxígeno puntúa 0 en SpO2 (+2 por oxígeno)."""
    result = calculate_news2(_spo2_measurement(spo2_scale=1))
    assert result.scale_used == 'Escala 1'
    assert result.total_score == 2


def test_spo2_scale_2_only_when_explicitly_selected():
    """La Escala 2 solo se aplica si se indica: SpO2 97% con oxígeno puntúa 3 (+2 por oxígeno)."""
    result = calculate_news2(_spo2_measurement(spo2_scale=2))
    assert result.scale_used == 'Escala 2'
    assert result.total_score == 5


def test_missing_oxygen_flag_is_reported_not_assumed_false():
    """Si falta 'oxígeno suplementario' no se asume 'aire': la evaluación queda incompleta."""
    measurement = _spo2_measurement(spo2_scale=1)
    measurement.supplemental_oxygen = None
    result = calculate_news2(measurement)
    assert result.is_complete is False
    assert result.total_score is None
    assert 'Oxígeno suplementario' in result.missing_parameters
